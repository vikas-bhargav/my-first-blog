

# -*- coding: utf-8 -*-
# baseUrl = 'https://www.companywatch.net/login/'
import time
import xlsxwriter
from selenium import webdriver
from bs4 import BeautifulSoup


# user = 'vbhargav'
user = 'binpandey'
# pwd = 'cignex#1370'
pwd = 'Prasad_0318@01'
httpproxy = 'http://' + user + ':' + pwd + '@proxy:80/'
httpsproxy = 'https://' + user + ':' + pwd + '@proxy:80/'
proxyDict = {"http": httpproxy, "https": httpsproxy}

driver = webdriver.Chrome(r'C:\Users\vbhargav\Documents\drivers\241\chromedriver.exe')


# Function for getting tables
def main(base_url, list_of_postal_code):
    """
    Function for getting table data from web page.
    :param base_url: Base url for web page
    :return: List of dictionary of table data
    """
    driver.get(base_url) # Get base url page data
    # # Get email & password elements
    # email_field = driver.find_element_by_name("email")
    # password_field = driver.find_element_by_name("password")
    search_field = driver.find_element_by_id("txtPostCode")
    # # Pass email & password values
    # email_field.send_keys(email)
    # password_field.send_keys(password)
    search_field.send_keys(list_of_postal_code[0])
    # # Get Login button element
    # # login_element = driver.find_element_by_xpath("//input[contains(@class,'buttonAlt right')]")
    # # login_element.submit()  # Submit login form
    submit_element = driver.find_element_by_xpath("//button[contains(@type,'submit')]")
    submit_element.submit()  # Submit search value
    search_page_reference = driver.page_source

    soup = BeautifulSoup(search_page_reference)  # Get home page data
    print("---------")
    page_element = driver.find_element_by_class_name("next")
    page_element.click()
    print(page_element)
    exit(0)

    # print("Soup...........")
    # print(soup)
    # Get next page
    next_page = soup.find('tbody')
    # Get table
    table_body = soup.find('tbody')
    rows = table_body.find_all('tr')
    column_list = list()
    for row in rows:
        cols = row.find_all('td')
        cols = [x.text.strip() for x in cols]
        # print(cols)
        if "WARD" in cols[0] or "Long Stay" in cols[0]:
            column_list.append(cols)
        else:
            print("false: ", cols[0])
    print(column_list)
    print(len(column_list))
    exit(0)
    # ------------------------------------ #
    update_date = soup.find("div", {"class": "new"}).find('small').text #.find("i", {"class": "fa fa-calendar-o"}).text
    update_date = update_date.split(":")[-1]
    print("update_date: ", update_date.strip())
    supply_database_link = 'https://www.ampmhotels.com' + soup.find('a', {'title': 'Supply Database'})['href']
    driver.get(supply_database_link)
    # Get page first and last page no.
    supply_data_source = driver.page_source
    first_page_data = BeautifulSoup(supply_data_source, "lxml")
    last_page_no = first_page_data.find("div", {"class": "pagination"}).findAll("a")[-2].text
    # Get headers
    header_row = first_page_data.find('thead').findAll('th')
    header_list = [x.find(text=True).strip() for x in header_row]
    final_data_list = list()
    column_list = list()
    # for page in range(1, int(last_page_no) + 1):
    # for page in range(1, (int(last_page_no) + 1)):
    for page in range(1, 2):
        page_url = 'https://www.ampmhotels.com/live/database.php?page=' + str(page) + '&ipp=50&t=s'
        driver.get(page_url)  # Get page
        each_page_reference = driver.page_source  # Get page source
        page_soup = BeautifulSoup(each_page_reference, "lxml")  # parse page
        table_body = page_soup.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows:
            cols = row.find_all('td')
            cols = [x.text.strip() for x in cols]
            column_list.append(cols)

    final_data_list.append(header_list)
    final_data_list.append(column_list)
    final_data_list.append(update_date)
    return final_data_list


# Write data into file
def write_data_into_excel_file(supply_data_list):
    """
    Function for write the extracted data from supply database web page in to excel file.
    :param supply_data_list: List of extracted data from supply database web page.
    :return:
    """
    file_name = 'ampmhotels_data' + str(supply_data_list[2]).replace(" ", "_") + '.xlsx'
    # Create a workbook object
    workbook = xlsxwriter.Workbook(file_name)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format({'bold': 1})
    # Write some data headers.
    head_col = 0
    head_row = 0
    for header in supply_data_list[0]:
        worksheet.write(head_row, head_col, header, bold)
        head_col += 1
    # Start from the first cell below the headers.
    row = 1
    for row_list in supply_data_list[1]:
        col = 0
        for colm in row_list:
            worksheet.write(row, col, colm)
            col += 1
        row += 1
    workbook.close()


if __name__ == '__main__':
    start = time.time()
    baseUrl = 'http://cti.voa.gov.uk/cti/inits.asp'
    # username = 'mlazorina@deloitte.co.uk'
    # password = "holborn102"
    list_of_postal_code = ["PO19 6SE"]
    supply_data = main(baseUrl, list_of_postal_code)  # Calling main function
    print("supply database length: ", len(supply_data[1]))
    # write_data_into_excel_file(supply_data)  # For writing data into file
    # print('It took', (time.time() - start)/60, 'minutes.')
