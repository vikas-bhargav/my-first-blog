# -*- coding: utf-8 -*-
import time
import xlrd
import xlsxwriter
from selenium import webdriver
from bs4 import BeautifulSoup
from datetime import datetime


driver = webdriver.Chrome(r'C:\Users\vbhargav\Documents\drivers\241\chromedriver.exe')
driver.set_page_load_timeout(200000)
# Function for getting tables


def main(base_url, postal_code, ref_time):
    """
    Function for getting table data from web page.
    :param base_url: Base url for web page
    :return: List of table data
    """
    print("-------- main ---------- : ", postal_code)
    driver.get(base_url)  # Get base url page data
    search_field = driver.find_element_by_id("txtPostCode")
    search_field.send_keys(postal_code)
    submit_element = driver.find_element_by_xpath("//button[contains(@type,'submit')]")
    submit_element.submit()  # Submit search value
    search_page_reference = driver.page_source

    soup = BeautifulSoup(search_page_reference)  # Parse page data
    flag = True
    column_list = list()
    count = 1
    soup_s = soup
    while flag:
        try:
            # Get table
            table_body = soup_s.find('tbody')
            rows = table_body.find_all('tr')
            for row in rows:
                cols = row.find_all('td')
                cols = [x.text.strip() for x in cols]
                # print("cols[0]: ", cols[0].split())
                if "WARD" in cols[0] or "Long Stay" in cols[0]:
                    column_list.append(cols)
                else:
                    pass  # print("false: ", cols[0])

            try:
                page_element_2 = driver.find_element_by_class_name("next")
                page_element_2.click()
                search_page_reference2 = driver.page_source
                soup_s = BeautifulSoup(search_page_reference2)

                count += 1
            except:
                flag = False
        except:
            # if ref_time >= 3:
            #     print("Server issue please run script again .............. ")
            #     exit(0)
            # else:
            #     ref_time = ref_time + 1
            #     print("refresh count .......: ", ref_time)
            #     column_list = main(base_url, postal_code, ref_time)
            pass
    return column_list


# Write data into file
def write_data_into_excel_file(final_list):
    """
    Function for write the extracted data into the excel file.
    :param finallist: List of extracted data from web page.
    :return:
    """
    now = datetime.now().date()
    print("now: ", now)
    file_name = 'voa_data' + str(now) + '.xlsx'
    # Create a workbook object
    workbook = xlsxwriter.Workbook(file_name)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format({'bold': 1})
    # Write some data headers.
    head_col = 0
    head_row = 0
    data_header_list = ["Address", "Council Tax band", "Local authority reference number"]
    for header in data_header_list:
        worksheet.write(head_row, head_col, header, bold)
        head_col += 1
    # Start from the first cell below the headers.
    row = 1
    for row_list in final_list:
        worksheet.write(row, 0, row_list[0])
        worksheet.write(row, 1, row_list[1])
        worksheet.write(row, 2, row_list[3])
        row += 1
    workbook.close()


# Read postal code excel file
def read_postal_code(file_location):
    wb = xlrd.open_workbook(file_location)
    sheet = wb.sheet_by_index(0)
    # For row 0 and column 0
    sheet.cell_value(0, 0)
    postal_code_list = list()
    for i in range(sheet.nrows):
        postal_code_list.append(sheet.cell_value(i, 0))
    return postal_code_list


if __name__ == '__main__':
    start = time.time()
    ref_time = 0
    baseUrl = 'http://cti.voa.gov.uk/cti/inits.asp'
    file_location = "postal_codes_detail_02.xlsx"
    # list_of_postal_code = ["PO19 6SE"]
    list_of_postal_code = read_postal_code(file_location)
    print(list_of_postal_code)
    final_list = list()
    if len(list_of_postal_code) >= 1:
        for postal_code in list_of_postal_code[1:]:
            postal_code_data = main(baseUrl, postal_code, ref_time)  # Calling main function
            if len(postal_code_data) >= 1:
                final_list = final_list + postal_code_data

    print("final_list length: ", len(final_list))
    print("final_list : ", final_list)
    if len(final_list) >= 1:
        write_data_into_excel_file(final_list)  # For writing data into file
    print('It took', (time.time() - start)/60, 'minutes.')
