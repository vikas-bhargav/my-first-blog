# -*- coding: utf-8 -*-
import time
import xlrd
import xlsxwriter
from selenium import webdriver
from bs4 import BeautifulSoup
from datetime import datetime


driver = webdriver.Chrome(r'C:\Users\vbhargav\Documents\drivers\241\chromedriver.exe')
driver.set_page_load_timeout(200000)
# Function for getting tables


# Read postal code excel file
def read_postal_code(file_location):
    wb = xlrd.open_workbook(file_location)
    sheet = wb.sheet_by_index(0)
    # For row 0 and column 0
    sheet.cell_value(0, 0)
    postal_code_list = list()
    for i in range(sheet.nrows):
        postal_code_list.append(sheet.cell_value(i, 0))
    return postal_code_list


# Write data into file
def write_data_into_excel_file(final_list):
    """
    Function for write the extracted data into the excel file.
    :param finallist: List of extracted data from web page.
    :return:
    """
    now = datetime.now().date()
    print("now: ", now)
    file_name = 'voa_data' + str(now) + '.xlsx'
    # Create a workbook object
    workbook = xlsxwriter.Workbook(file_name)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format({'bold': 1})
    # Write some data headers.
    head_col = 0
    head_row = 0
    data_header_list = ["Address", "Council Tax band", "Local authority reference number", "Postal Code"]
    for header in data_header_list:
        worksheet.write(head_row, head_col, header, bold)
        head_col += 1
    # Start from the first cell below the headers.
    row = 1
    for row_list in final_list:
        worksheet.write(row, 0, row_list[0])
        worksheet.write(row, 1, row_list[1])
        worksheet.write(row, 2, row_list[3])
        worksheet.write(row, 3, row_list[4])
        row += 1
    workbook.close()


def main(base_url, postal_code, ref_time):
    """
    Function for getting table data from web page.
    :param base_url: Base url for web page
    :return: List of table data
    """
    print("-------- main ---------- : ", postal_code)
    column_list = list()
    driver.get(base_url)  # Get base url page data
    address_field = driver.find_element_by_id("txtNameNum")
    search_field = driver.find_element_by_id("txtPostCode")
    address_field.send_keys("WARD")
    search_field.send_keys(postal_code)
    submit_element = driver.find_element_by_xpath("//button[contains(@type,'submit')]")
    submit_element.submit()   # Submit search value
    search_page_reference = driver.page_source

    soup = BeautifulSoup(search_page_reference)  # Parse page data
    # ----------------
    try:

        data_div = soup.find('div', {'class': 'scl_complex'})
        table_data = data_div.find("table")
        if table_data.has_attr('title'):
            print("inside if_____________")
            try:
                # Get table
                table_body = table_data.find('tbody')
                rows = table_body.find_all('tr')
                for row in rows:
                    cols = row.find_all('td')
                    cols = [x.text.strip() for x in cols]
                    cols.append(postal_code)
                    column_list.append(cols)

            except Exception as e:
                print("No tables found........")

        else:
            print("inside else_____________")
            # Get table
            table_body = table_data.find('tbody')
            href_list = table_body.find_all('a')
            for href in href_list:
                driver.execute_script(href['href'])
                page_table = driver.page_source
                soup_adv = BeautifulSoup(page_table)
                t = soup_adv.find("table", {"title": "Search results"})
                #
                try:
                    # Get table
                    table_body = t.find('tbody')
                    rows = table_body.find_all('tr')
                    for row in rows:
                        cols = row.find_all('td')
                        cols = [x.text.strip() for x in cols]
                        cols.append(postal_code)
                        column_list.append(cols)
                        # column_list.append(postal_code)

                except:
                    print("No tables found........")
                # Back to page
                driver.back()
    except:
        print("No data found with :  ", postal_code)
        print(driver.title)
        if driver.title == 'Internal Server Error' and ref_time < 3:
            print(".............Internal Server Error...............")
            ref_time = ref_time + 1
            main(base_url, postal_code, ref_time)


        print("-----------------------------------------------")


    print("list_:", column_list)
    print("list_:", len(column_list))

    return column_list


if __name__ == '__main__':
    start = time.time()
    ref_time = 0
    # baseUrl = 'http://cti.voa.gov.uk/cti/inits.asp'
    baseUrl = 'http://cti.voa.gov.uk/cti/RefS.asp?lcn=0'
    # file_location = "postal_codes_detail_02.xlsx"
    file_location = "new_postal_codes.xlsx"
    # list_of_postal_code = ["PO19 6SE"]
    list_of_postal_code = read_postal_code(file_location)
    print(list_of_postal_code)
    final_list = list()
    if len(list_of_postal_code) >= 1:
        for postal_code in list_of_postal_code[1:5]:
            postal_code_data = main(baseUrl, postal_code[:-2], ref_time)  # Calling main function
            if len(postal_code_data) >= 1:
                final_list = final_list + postal_code_data
            # print(postal_code[:-2])
    print("final_list length: ", len(final_list))
    print("final_list : ", final_list)
    if len(final_list) >= 2:
        write_data_into_excel_file(final_list)  # For writing data into file
    print('It took', (time.time() - start)/60, 'minutes.')
