# -*- coding: utf-8 -*-
import time
import xlsxwriter
from selenium import webdriver
from bs4 import BeautifulSoup
from datetime import datetime


# user = 'vbhargav'
user = 'binpandey'
# pwd = 'cignex#1370'
pwd = 'Prasad_0318@01'
httpproxy = 'http://' + user + ':' + pwd + '@proxy:80/'
httpsproxy = 'https://' + user + ':' + pwd + '@proxy:80/'
proxyDict = {"http": httpproxy, "https": httpsproxy}

driver = webdriver.Chrome(r'C:\Users\vbhargav\Documents\drivers\241\chromedriver.exe')

ref_time  = 0
# Function for getting tables
def main(base_url, postal_code):
    """
    Function for getting table data from web page.
    :param base_url: Base url for web page
    :return: List of table data
    """
    print("-------- main ---------- : ", postal_code)
    driver.get(base_url)  # Get base url page data
    search_field = driver.find_element_by_id("txtPostCode")
    search_field.send_keys(postal_code)
    submit_element = driver.find_element_by_xpath("//button[contains(@type,'submit')]")
    submit_element.submit()  # Submit search value
    # submit_element.click()  # Submit search value
    search_page_reference = driver.page_source

    soup = BeautifulSoup(search_page_reference)  # Get home page data
    flag = True
    column_list = list()
    count = 1
    soup_s = soup
    while flag:
        try:
            # Get table
            table_body = soup_s.find('tbody')
            rows = table_body.find_all('tr')
            for row in rows:
                cols = row.find_all('td')
                cols = [x.text.strip() for x in cols]
                if "WARD" in cols[0]:
                    column_list.append(cols)
                else:
                    pass  # print("false: ", cols[0])

            try:
                page_element_2 = driver.find_element_by_class_name("next")
                page_element_2.click()
                search_page_reference2 = driver.page_source
                soup_s = BeautifulSoup(search_page_reference2)

                count += 1
            except:
                flag = False
        except:
            print("Server issue.........")
            if ref_time >= 3:
                exit(0)
            else:
                ref_time =+ 1
    return column_list


# Write data into file
def write_data_into_excel_file(final_list):
    """
    Function for write the extracted data into the excel file.
    :param finallist: List of extracted data from web page.
    :return:
    """
    now = datetime.now().date()
    print("now: ", now)
    file_name = 'voa_data' + str(now) + '.xlsx'
    # Create a workbook object
    workbook = xlsxwriter.Workbook(file_name)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format({'bold': 1})
    # Write some data headers.
    head_col = 0
    head_row = 0
    data_header_list = ["Address", "Council Tax band", "Local authority reference number"]
    for header in data_header_list:
        worksheet.write(head_row, head_col, header, bold)
        head_col += 1
    # Start from the first cell below the headers.
    row = 1
    for row_list in final_list:
        col = 0
        # for colm in row_list:
        # worksheet.write(row, col, colm)
        worksheet.write(row, 0, row_list[0])
        worksheet.write(row, 1, row_list[1])
        worksheet.write(row, 2, row_list[3])
            # col += 1
        row += 1
    workbook.close()


if __name__ == '__main__':
    start = time.time()
    baseUrl = 'http://cti.voa.gov.uk/cti/inits.asp'
    list_of_postal_code = ["PO19 6SE"] # ["PO19 6SE", "EC1A 7BE", "NW3 2QC", "SE18 4QH", "NW10 7NS"]
    final_list = list()
    for postal_code in list_of_postal_code:
        postal_code_data = main(baseUrl, postal_code)  # Calling main function
        # print("Postal_code_data length: ", len(postal_code_data))
        if len(postal_code_data) >= 1:
            final_list = final_list + postal_code_data

    print("final_list length: ", len(final_list))
    print("final_list : ", final_list)
    if len(final_list) >= 1:
        write_data_into_excel_file(final_list)  # For writing data into file
    # print('It took', (time.time() - start)/60, 'minutes.')
